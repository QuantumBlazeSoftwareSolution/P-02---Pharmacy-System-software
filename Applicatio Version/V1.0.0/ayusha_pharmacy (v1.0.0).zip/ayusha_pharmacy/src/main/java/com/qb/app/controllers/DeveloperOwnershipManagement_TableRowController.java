
package com.qb.app.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class DeveloperOwnershipManagement_TableRowController implements Initializable {

 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
