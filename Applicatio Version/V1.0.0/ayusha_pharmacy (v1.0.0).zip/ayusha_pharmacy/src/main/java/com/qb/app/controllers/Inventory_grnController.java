package com.qb.app.controllers;

import com.qb.app.App;
import com.qb.app.controllers.report.beans.GrnItemBean;
import com.qb.app.model.ComboBoxUtils;
import com.qb.app.model.CustomAlert;
import com.qb.app.model.DefaultAPI;
import com.qb.app.model.JPATransaction;
import com.qb.app.model.PopUp;
import com.qb.app.model.SVGIconGroup;
import com.qb.app.model.entity.Company;
import com.qb.app.model.entity.Grn;
import com.qb.app.model.entity.GrnItem;
import com.qb.app.model.entity.Product;
import com.qb.app.model.entity.ProductHasProductType;
import com.qb.app.model.entity.ProductStatus;
import com.qb.app.model.entity.Stock;
import com.qb.app.model.entity.Supplier;
import com.qb.app.model.getLogger;
import com.qb.app.session.ApplicationSession;
import com.qb.app.session.CompanyInfo;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.io.IOException;
import java.net.URL;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Inventory_grnController implements Initializable {

    // <editor-fold desc="FXML init component" defaultstate="collapsed">
    @FXML
    private ScrollPane grnTableScrollContainer;
    @FXML
    private VBox grnTableBody;
    @FXML
    private ScrollBar grnTableScroller;
    @FXML
    private Group GrnIcon;
    @FXML
    private ComboBox<Company> cbCompany;
    @FXML
    private ComboBox<Supplier> cbSupplier;
    @FXML
    private TextField tfGRNID;
    @FXML
    private TextField tfProductID;
    @FXML
    private TextField tfProductName;
    @FXML
    private TextField tfGenericName;
    @FXML
    private TextField tfCostPrice;
    @FXML
    private TextField tfQty;
    @FXML
    private TextField tfAmount;
    @FXML
    private TextField tfTotal;
    @FXML
    private Button btnAction;
    @FXML
    private AnchorPane root;
    @FXML
    private Label displayMessage;
    //</editor-fold>

    private Product loadedProduct;
    private boolean readyItemToAdd;
    private double itemQty;
    private Grn savedGrn;
    List<InventoryGRN_TableRowController> grnItemList = new ArrayList<>();
    @FXML
    private TextField tfDiscount;
    @FXML
    private Button btnItemAdd;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tfCostPrice.setDisable(false);
        tfQty.setDisable(false);
        DefaultAPI.bindTableScroll(grnTableScroller, grnTableScrollContainer, grnTableBody);
        GrnIcon.getChildren().add(new SVGIconGroup("/com/qb/app/assets/icons/page-icon.svg"));
        tfQty.setTextFormatter(DefaultAPI.createNumericTextFormatter());
        tfCostPrice.setTextFormatter(DefaultAPI.createNumericTextFormatter());
        loadComboBox();
    }

    private void loadComboBox() {
        ComboBoxUtils.loadComboBoxValues(cbCompany, Company.class, "name", Company::getName);
        ComboBoxUtils.loadComboBoxValues(cbSupplier, Supplier.class, "name", Supplier::getName);
    }

    @FXML
    private void actionEvent(ActionEvent event) {
        if (event.getSource() == btnAction) {
            makeGrn();
        } else if (event.getSource() == btnItemAdd) {
            validateAndAddItem();
        }
    }

    private void makeGrn() {
        if (isEntriesValid()) {
            if (isGrnIdAvailable()) {
                if (grnItemList.isEmpty() || grnItemList.size() == 0 || grnItemList == null) {
                    CustomAlert.showStyledAlert(
                            root,
                            "Cannot process GRN without any items. Please add at least one product to the GRN list.",
                            "Empty GRN Items",
                            Alert.AlertType.WARNING
                    );
                } else {
                    createGrn();
                }
            } else {
                CustomAlert.showStyledAlert(root, "This GRN number is already registered in the system.", "GRN Duplication Warning", Alert.AlertType.WARNING);
            }
        }
    }
    
    public void removeInvoiceItem(InventoryGRN_TableRowController itemToRemove) {
        Node nodeToRemove = itemToRemove.getRootNode();

        grnItemList.remove(itemToRemove);
        grnTableBody.getChildren().remove(nodeToRemove);

        calculateTotal();
    }
    
    private boolean isEntriesValid() {
        if (cbCompany.getValue() == null) {
            displayWarningMessage("Please select the supply company", false);
            cbCompany.requestFocus();
            return false;
        }

        if (cbSupplier.getValue() == null) {
            displayWarningMessage("Please select the supplier", false);
            cbSupplier.requestFocus();
            return false;
        }

        if (tfGRNID.getText().isEmpty()) {
            displayWarningMessage("Please enter the grn id", false);
            tfGRNID.requestFocus();
            return false;
        }

        return true;
    }

    private boolean isGrnIdAvailable() {
        return JPATransaction.runInTransaction((em) -> {
            String grnID = tfGRNID.getText();
            Supplier selectedSupplier = cbSupplier.getValue();

            if (grnID == null || grnID.isEmpty() || selectedSupplier == null) {
                return true;
            }

            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Long> cq = cb.createQuery(Long.class);
            Root<Grn> grnTable = cq.from(Grn.class);

            Predicate grnCodePredicate = cb.equal(grnTable.get("grnCode"), grnID);
            Predicate supplierPredicate = cb.equal(grnTable.get("supplierId"), selectedSupplier);

            cq.select(cb.count(grnTable))
                    .where(cb.and(grnCodePredicate, supplierPredicate));

            return em.createQuery(cq).getSingleResult() == 0;
        });
    }

    private void createGrn() {

        JPATransaction.runInTransaction((em) -> {
            double discount = 0;
            if (!tfDiscount.getText().isEmpty()) {
                discount = Double.parseDouble(tfDiscount.getText());
            }
            Grn grn = new Grn();
            grn.setGrnCode(tfGRNID.getText());
            grn.setDateTime(new Date());
            grn.setSupplierId(cbSupplier.getValue());
            grn.setDiscount(discount);
            em.persist(grn);
            em.flush();

            this.savedGrn = grn;

            for (InventoryGRN_TableRowController item : grnItemList) {
                GrnItem grnItem = new GrnItem();
                grnItem.setCostPrice(item.getCost());
                grnItem.setQty(item.getQty());
                grnItem.setProductId(item.getProduct());
                grnItem.setGrnId(grn);
                em.persist(grnItem);
                em.merge(item.getProduct());

                CriteriaBuilder cb = em.getCriteriaBuilder();
                CriteriaQuery<Stock> cq = cb.createQuery(Stock.class);
                Root<Stock> stockTable = cq.from(Stock.class);
                cq.where(cb.equal(stockTable.get("productId"), item.getProduct()));

                Stock stock = em.createQuery(cq).getSingleResult();
                stock.setQty(stock.getQty() + (item.getQty() * item.getProduct().getMeasure()));
                em.persist(stock);
            }

            printGrnReport(grn);
            grnItemList.clear();
            grnTableBody.getChildren().clear();
            tfTotal.setText("");
            tfGRNID.setText("");
            cbCompany.setValue(null);
            cbSupplier.setValue(null);
            tfDiscount.setText("");
        });
    }

    private void displayWarningMessage(String message, boolean action) {
        if (action) {
            displayMessage.setStyle("-fx-text-fill: #0D9F00;"); // Green
        } else {
            displayMessage.setStyle("-fx-text-fill: #FF3333;"); // Red
        }
        displayMessage.setText(message);

        PauseTransition delay = new PauseTransition(Duration.seconds(10));
        delay.setOnFinished(event -> displayMessage.setText(""));
        delay.play();
    }

    @FXML
    private void handlePopUpProductView(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            if (tfProductID.getText().isEmpty()) {
                try {
                    PopUp.showPopupAndWait(
                            "popUpProductList.fxml",
                            tfProductID,
                            this.root.getScene(),
                            PopUp.PopupType.CENTERED_80_WIDTH,
                            (PopUpProductListController controller) -> {
                                controller.saveProductRegistrationController(this);
                            }
                    );
//                    FXMLLoader loader = new FXMLLoader(App.class.getResource("popUpProductList.fxml"));
//                    Parent root = loader.load();
//
//                    // Create a new stage for the popup
//                    Stage popupStage = new Stage();
//                    popupStage.initOwner(tfProductID.getScene().getWindow());
//                    popupStage.initModality(Modality.APPLICATION_MODAL);
//
//                    // Get screen dimensions
//                    Screen screen = Screen.getPrimary();
//                    Rectangle2D bounds = screen.getVisualBounds();
//
//                    // Create scene with full width but original height
//                    Scene scene = new Scene(root);
//                    popupStage.setScene(scene);
//
//                    // Set width to screen width and position at x=0
//                    popupStage.setWidth(bounds.getWidth());
//                    popupStage.setX(0); // This ensures no left gap
//
//                    // Set fixed height (adjust as needed)
//                    popupStage.setHeight(600);
//
//                    // Center the popup vertically
//                    popupStage.setY((bounds.getHeight() - popupStage.getHeight()) / 2);
//
//                    popupStage.initStyle(StageStyle.TRANSPARENT);
//
//                    // Get controller reference
//                    PopUpProductListController controller = loader.getController();
//                    controller.saveProductRegistrationController(this);
//
//                    popupStage.showAndWait();
                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger.logger().warning(e.toString());
                }
            } else {
                loadProductDetails();
            }
        }
    }

    public void setParentID(String id) {
        tfProductID.setText(id);
    }

    private void loadProductDetails() {
        JPATransaction.runInTransaction((em) -> {
            try {
                int productID = Integer.parseInt(tfProductID.getText());
                Product product = em.find(Product.class, productID);
                if (product != null) {
                    if (isParentProduct(product)) {
                        this.loadedProduct = product;
                        tfProductName.setText(product.getProduct());
                        tfGenericName.setText(product.getGenericName());
                        tfCostPrice.setText(String.valueOf(product.getCostPrice()));
                        tfQty.setText("1");
                        tfCostPrice.setDisable(false);
                        tfQty.setDisable(false);
                        tfCostPrice.requestFocus();
                    } else {
                        displayWarningMessage("Cannot proceed with child product.", false);
                        clearLoadedTextFields();
                    }
                } else {
                    displayWarningMessage("Product not found.", false);
                }
            } catch (Exception e) {
                displayWarningMessage("Invalid Product ID.", false);
            }
        });
    }

    private void calculateLoadedItemAmount() {
        int qty = Integer.parseInt(tfQty.getText());
        try {
            double costPrice = Double.parseDouble(tfCostPrice.getText());
            this.itemQty = qty;
            double productAmount = costPrice * qty;
            tfAmount.setText(String.format("Rs. %,.2f", productAmount));
            this.readyItemToAdd = true;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            getLogger.logger().warning(e.toString());
        }
    }

    @FXML
    private void qtyListener(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            validateAndAddItem();
        } else {
            this.readyItemToAdd = false;
        }
    }

    private void validateAndAddItem() {
        if (this.readyItemToAdd) {
            addItemToList();
        } else {
            String qty = tfQty.getText();
            if (qty.isEmpty() || Integer.parseInt(qty) <= 0) {
                displayWarningMessage("To proceed, please enter the quantity for this product.", false);
                this.readyItemToAdd = false;
            } else {
                calculateLoadedItemAmount();
            }
        }
    }

    private void addItemToList() {
        if (tfCostPrice.getText().isEmpty()) {
            displayWarningMessage("Cost price is required. Please enter a value.", false);
        } else {
            try {
                boolean itemExists = false;

                for (InventoryGRN_TableRowController item : grnItemList) {
                    if (item.getProductID() == loadedProduct.getId()) {
                        item.setProductQty(item.getQty() + itemQty);
                        itemExists = true;
                        break;
                    }
                }

                if (!itemExists) {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/qb/app/fxmlComponent/InventoryGRN_TableRow.fxml"));
                    Node grnItem = loader.load();
                    InventoryGRN_TableRowController controller = loader.getController();
                    controller.setData(
                            loadedProduct, 
                            loadedProduct.getId(), 
                            loadedProduct.getProduct(), 
                            Double.parseDouble(tfCostPrice.getText()), itemQty,
                            grnItem,
                            this
                    );

                    loadedProduct.setCostPrice(Double.parseDouble(tfCostPrice.getText()));

                    grnItemList.add(controller);
                    grnTableBody.getChildren().add(grnItem);
                }

                calculateTotal();
                clearLoadedTextFields();
                resetFields();
            } catch (IOException e) {
                e.printStackTrace();
                getLogger.logger().warning(e.toString());
            } catch (NumberFormatException e) {
                e.printStackTrace();
                getLogger.logger().warning(e.toString());
            }
        }
    }

    private void resetFields() {
        this.loadedProduct = null;
        this.readyItemToAdd = false;
        this.itemQty = 0;
        tfQty.setDisable(true);
    }

    private void clearLoadedTextFields() {
        tfProductID.setText("");
        tfProductName.setText("");
        tfGenericName.setText("");
        tfCostPrice.setText("");
        tfQty.setText("");
        tfAmount.setText("");

        tfProductID.requestFocus();
    }

    private void printGrnReport(Grn grn) {
        Map<String, Object> params = getJRParams();
        Vector<GrnItemBean> collection = getBeanCollection();

        try {
            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(
                    getClass().getResourceAsStream("/com/qb/app/reports/PharmacyGRN.jasper"));

            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(collection);

            JasperPrint report = JasperFillManager.fillReport(jasperReport, params, dataSource);
//            JasperPrintManager.printReport(report, false);
//            JasperViewer.viewReport(report, false);
            JasperViewer viewer = new JasperViewer(report, false);
            viewer.setAlwaysOnTop(true);
            viewer.setVisible(true);
        } catch (JRException e) {
            e.printStackTrace();
            getLogger.logger().warning(e.toString());
            CustomAlert.showStyledAlert(root, "Report generation failed: " + e.getMessage(), "Reporting Error", Alert.AlertType.ERROR);
        }
    }

    private Map<String, Object> getJRParams() {
        Map<String, Object> params = new HashMap<>();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a");
        String grnTime = savedGrn.getDateTime().toInstant().atZone(ZoneId.systemDefault()).format(formatter);

        params.put("GrnTime", grnTime);
        params.put("GrnID", savedGrn.getGrnCode());
        params.put("Supplier", cbSupplier.getValue().getName());
        params.put("CompanyName", CompanyInfo.companyName);
        params.put("Contact", CompanyInfo.mobile);
        params.put("Address", CompanyInfo.address);
        params.put("Address", CompanyInfo.address);
        getGrnTotal(params);
        params.put("Employee", ApplicationSession.getEmployee().getName());

        return params;
    }

    private Vector<GrnItemBean> getBeanCollection() {

        Vector<GrnItemBean> collection = new Vector<>();
        for (InventoryGRN_TableRowController item : grnItemList) {
            GrnItemBean bean = new GrnItemBean(
                    String.valueOf(item.getProduct().getId()),
                    item.getProduct().getProduct(),
                    item.getProduct().getGenericName() != null ? item.getProduct().getGenericName() : "N/A",
                    String.format("%,.2f", item.getProduct().getCostPrice()),
                    String.valueOf(item.getQty()),
                    String.format("%,.2f", item.getItemAmount())
            );
            collection.add(bean);
        }

        return collection;
    }

    private void getGrnTotal(Map<String, Object> params) {

        double total = 0;
        double discount = 0;

        if (!tfDiscount.getText().isEmpty()) {
            discount = Double.parseDouble(tfDiscount.getText());
        }

        for (InventoryGRN_TableRowController item : grnItemList) {
            total += item.getItemAmount();
        }
        params.put("SubTotal", String.format("Rs. %,.2f", total));
        params.put("Discount", String.format("Rs. %,.2f", discount));
        params.put("Total", String.format("Rs. %,.2f", total));
        params.put("TotalQty", String.valueOf(grnItemList.size()));
    }

    private void calculateTotal() {
        double total = 0;
        for (InventoryGRN_TableRowController item : grnItemList) {
            total += item.getItemAmount();
        }
        if (!tfDiscount.getText().isEmpty()) {
            double discount = Double.parseDouble(tfDiscount.getText());
            total -= discount;
        }
        tfTotal.setText(String.format("Rs. %,.2f", total));
    }

    @FXML
    private void costPriceListener(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            calculateLoadedItemAmount();
            tfQty.requestFocus();
        }
    }

    @FXML
    private void handleDiscount(KeyEvent event) {
        calculateTotal();
    }

    private boolean isParentProduct(Product product) {
        return JPATransaction.runInTransaction((em) -> {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<ProductHasProductType> cq = cb.createQuery(ProductHasProductType.class);
            Root<ProductHasProductType> typeTable = cq.from(ProductHasProductType.class);

            Predicate prdcts = cb.equal(typeTable.get("productId"), product);
            cq.where(prdcts);

            ProductHasProductType productType = em.createQuery(cq).getSingleResult();

            return productType.getProductTypeId().getType().equals("Parent");
        });
    }

}
